<h1>Sistem Penilaian Kinerja Pegawai dengan menggunakan Fuzzy Tsukamoto</h1>
