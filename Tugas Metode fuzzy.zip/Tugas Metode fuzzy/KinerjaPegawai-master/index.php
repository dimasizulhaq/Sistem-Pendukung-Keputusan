<?php
header('Location: login_pegawai.php');
?>